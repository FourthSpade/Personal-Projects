#!/bin/bash
apt install ansible -y
apt install openssh-client openssh-server -y
apt install libpam-pkcs11 -y
apt install auditd -y
apt install chrony -y
mkdir /etc/pam_pkcs11
touch /etc/pam_pksc11/pam_pkcs11.conf
git clone https://github.com/OpenSC/pam_pkcs11.git
cp ./pam_pkcs11/etc/pam_pkcs11.conf.example.in /etc/pam_pkcs11/pam_pkcs11.conf
rm -rf pam_pkcs11
curl -k https://dl.dod.cyber.mil/wp-content/uploads/stigs/zip/scc-5.7.1_ubuntu18_ubuntu20_amd64_bundle.zip --output ./stig.zip
unzip ./stig.zip
cd scc-5.7.1_ubuntu18_amd64
dpkg -i scc-5.7.1.ubuntu.18_amd64.deb
cd /opt/scc
./scc
