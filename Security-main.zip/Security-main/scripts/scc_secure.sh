#!/bin/bash
ansible-galaxy install -p roles -r requirements.yml
ansible-playbook site.yml
sudo ansible-playbook ./highsev.yml
sudo ansible-playbook ./medSevA.yml
sudo ansible-playbook ./medSevD.yml
sudo ansible-playbook ./medSevC.yml
sudo ansible-playbook ./lowsev_adrian.yml
